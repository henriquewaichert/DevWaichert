let trilho1 = document.getElementById('trilho')
let body = document.querySelector('body')
let nav = document.querySelector('nav')
let header = document.getElementById('inicio')


trilho1.addEventListener('click', () => {
  trilho1.classList.toggle('light')
  body.classList.toggle('light')
  nav.classList.toggle('light')
  header.classList.toggle('light')
})

const abaMenu = document.querySelector('.aba-menu');
const menu = document.querySelector('.menu');
const closemenu = document.querySelector('.close-menu');
const trilho = document.querySelector('.trilho');
const links = document.querySelectorAll('.menu ul li a');

abaMenu.addEventListener('click', () => {
  menu.classList.add('active');
  trilho.classList.add('esconder-bolinha');
  abaMenu.classList.add('esconder');
});

closemenu.addEventListener('click', () => {
  menu.classList.remove('active');
  trilho.classList.remove('esconder-bolinha');
  abaMenu.classList.remove('esconder');
});

// Fecha o menu ao clicar em qualquer link
links.forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('active');
    trilho.classList.remove('esconder-bolinha');
    abaMenu.classList.remove('esconder');
  });
});