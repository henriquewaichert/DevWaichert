let trilho = document.getElementById('trilho')
let body = document.querySelector('body')
let nav = document.querySelector('nav')
let header = document.getElementById('inicio')


trilho.addEventListener('click', () => {
  trilho.classList.toggle('light')
  body.classList.toggle('light')
  nav.classList.toggle('light')
  header.classList.toggle('light')
})

const abaMenu = document.querySelector('.aba-menu');
const menu = document.querySelector('.menu');
const closemenu = document.querySelector('.close-menu');
const links = document.querySelectorAll('.menu ul li a');

abaMenu.addEventListener('click', () => {
  menu.classList.add('active');
  trilho.classList.add('esconder-bolinha');
});

closemenu.addEventListener('click', () => {
  menu.classList.remove('active');
  trilho.classList.remove('esconder-bolinha');
});

// Fecha o menu ao clicar em qualquer link
links.forEach(link => {
  link.addEventListener('click', () => {
    menu.classList.remove('active');
    trilho.classList.remove('esconder-bolinha');
  });
});